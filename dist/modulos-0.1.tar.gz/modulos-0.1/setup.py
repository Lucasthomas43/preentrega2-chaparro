from setuptools import setup

setup(
    name='modulos',
    version='0.1',
    author="chaparro lucas",
    description='paquete de clases distribuido',
    author_email='lucas.thomaas43@gmail.com',
    packages=["modulos"]
)

